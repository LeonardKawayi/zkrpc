package com.lagou.edu.zzk.zktask3;

import java.sql.Connection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Zktask3Application {

    public static void main(String[] args) throws Exception {
        SpringApplication.run(Zktask3Application.class, args);

        CustomerDataSource.init();
        Connection connection = CustomerDataSource.getConnection();
        System.out.println(connection);
    }

}

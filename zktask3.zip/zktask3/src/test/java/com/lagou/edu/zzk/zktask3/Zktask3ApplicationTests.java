package com.lagou.edu.zzk.zktask3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Zktask3ApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.lagou.edu.zdy_rpc_registry.handler;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.stereotype.Service;

import com.lagou.service.ConfigKeeper;
import com.lagou.service.RpcRegistryHandler;

/**
 * 注册中心工厂类
 */
@Service
public class RpcRegistryFactory implements FactoryBean<RpcRegistryHandler>, DisposableBean {

    private RpcRegistryHandler rpcRegistryHandler;

    @Override
    public RpcRegistryHandler getObject() throws Exception {
        if (null != rpcRegistryHandler) {
            return rpcRegistryHandler;
        }
        rpcRegistryHandler = new ZookeeperRegistryHandler(ConfigKeeper.getInstance().getZkAddr());
        return rpcRegistryHandler;
    }

    @Override
    public Class<?> getObjectType() {
        return RpcRegistryHandler.class;
    }

    @Override
    public void destroy() throws Exception {
        if (null != rpcRegistryHandler) {
            rpcRegistryHandler.destroy();
        }
    }
}

package com.lagou.client.loadbalance.impl;

import java.util.List;
import java.util.Random;

import com.lagou.client.client.RpcClient;
import com.lagou.client.loadbalance.AbstractLoadBalance;

/**
 * 随机负载策略
 */
public class RandomLoadBalance extends AbstractLoadBalance {

    @Override
    protected RpcClient doSelect(List<RpcClient> t) {
        int length = t.size();
        Random random = new Random();
        return t.get(random.nextInt(length));
    }
}
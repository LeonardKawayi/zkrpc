package com.lagou.client.loadbalance;

import java.util.List;
import java.util.Map;

import com.lagou.client.client.RpcClient;

/**
 * 负载均衡策略接口
 */
public interface LoadBalanceStrategy {

    /**
     * 获取请求客户端
     */
    RpcClient route(Map<String, List<RpcClient>> clientPool, String serviceClassName);
}
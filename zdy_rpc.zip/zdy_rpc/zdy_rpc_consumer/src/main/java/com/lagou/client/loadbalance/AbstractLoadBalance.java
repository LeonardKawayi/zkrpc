package com.lagou.client.loadbalance;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.MapUtils;

import com.lagou.client.client.RpcClient;

/**
 * 负载均衡策略抽象类
 */
public abstract class AbstractLoadBalance implements LoadBalanceStrategy {

    @Override
    public RpcClient route(Map<String, List<RpcClient>> clientPool, String serviceClassName) {
        if (MapUtils.isEmpty(clientPool)) {
            return null;
        }
        List<RpcClient> t = clientPool.get(serviceClassName);
        if (null == t) {
            return null;
        }
        return doSelect(t);
    }

    protected abstract RpcClient doSelect(List<RpcClient> t);
}

package com.lagou.service;

import java.util.Random;

import org.springframework.stereotype.Service;

@RpcService
@Service
public class UserServiceImpl implements UserService {

    @Override
    public String sayHello(String word) {
        Random random = new Random();
        int millis = random.nextInt(200);
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("接到请求:" + word + ", 服务端随机sleep:" + millis + "ms");
        return word;
    }
}

package com.lagou.service;

import java.io.IOException;

/**
 * @author zhangzhenkun <zhangzhenkun@kuaishou.com>
 * Created on 2020-03-26
 */
public interface Serializer {
    /**
     * java对象转换为二进制
     */

    byte[] serialize(Object object) throws IOException;

    /**
     * 二进制转换成java对象
     */

    <T> T deserialize(Class<T> clazz, byte[] bytes) throws IOException;
}

package com.lagou.service;

import java.util.List;

/**
 * 注册中心，用来做服务注册、服务发现
 */
public interface RpcRegistryHandler {

    /**
     * 服务注册
     */
    boolean registry(String service, String ip, int port);

    /**
     * 服务发现
     *
     * @param service wo
     */
    List<String> discovery(String service);

    /**
     * 添加监听者
     */
    void addListener(NodeChangeListener listener);

    /**
     * 注册中心销毁
     */
    void destroy();
}

package com.lagou.service;

import java.util.List;

import org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;

/**
 * 节点变更listener
 */
public interface NodeChangeListener {

    /**
     * 节点变更时通知listener
     */
    void notify(String children, List<String> serviceList, PathChildrenCacheEvent pathChildrenCacheEvent);
}
